#!/bin/sh
# acq test fixture: stands in for the Bash backend tree
